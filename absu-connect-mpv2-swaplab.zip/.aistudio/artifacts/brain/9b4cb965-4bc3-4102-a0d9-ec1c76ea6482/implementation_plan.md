# Phase 2 Blueprint: ABSU Connect Communities & Campus Events

A production-grade architectural blueprint and step-by-step implementation plan for expanding ABSU Connect with dedicated student **Communities** and **Campus Events** while preserving the current design language, branding, mobile responsiveness, and Supabase backend.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were confirmed during the Phase 1 planning interview and govern the technical and product implementation:

- **Community Post Scope in Home Feed**: **Confirmed**: Discussions posted inside a community will appear in the member's main Home Feed tagged with a distinct Community badge, in addition to being browsable in the community's dedicated Discussion tab.
- **Event Creation & Publishing Permissions**: **Confirmed**: All registered ABSU students can create events with direct publishing. Safety and legitimacy are guarded by post-publication moderation tools, community reporting flags, and the admin moderation console.
- **Phased Rollout Priority**: **Confirmed**: Communities will be implemented first (Discovery, Creation, Membership, Discussions, Roles, Moderation), followed by Campus Events (Calendar, Creation, RSVP/Going, Organizer Centre), with the optional Promotion/Monetization foundations coming in later phases without forcing student payments.

---

## 1. Codebase & Database Architecture Audit

### 1.1 Current Architecture Overview
The current ABSU Connect codebase runs as a full-stack React SPA with Express on Vite, connected to a Supabase PostgreSQL backend and a local server-side fallback store for resilience:
- **Frontend Entry**: `src/App.tsx` renders a desktop 3-column layout (`DesktopSidebar`, central `PullToRefresh` content column max-w-xl, and `DesktopRightSidebar`) and a mobile bottom navigation bar (`BottomNav.tsx`).
- **Active Navigation Routing**: State-based active view routing (`home`, `friends`, `messages`, `conversation`, `contact-info`, `games`, `alerts`, `profile`, `user-profile`, `marketplace`, `saved`, `events`, `communities`, `activity`, `safety`, `settings`, `more`, `mr-anonymous`).
- **Authentication**: `AuthContext.tsx` managing Supabase user sessions with matric-number/email sign-in, profile metadata (`currentUser`), and access token caching.
- **Real-Time & State**: `AppContext.tsx` managing users, friend relationships, feed filters, notifications, call sessions, theme resolution, and unread counters.

### 1.2 Existing Components & Features Reused
To avoid rebuilding social engines from scratch:
- **Feed & Card System**: `PostCard.tsx` and `PostMediaGallery.tsx` are fully reusable for community discussions by adding an optional `communityId` and `communityName` badge tag.
- **Post Composer & Media Uploads**: `PostComposer.tsx`, `CreatePostModal.tsx`, `storageService.ts` (`post-media` bucket uploads with client-side compression via `browser-image-compression`) can be invoked with community-specific contexts.
- **Social Interactivity**: Existing comment threads (`CommentSheet`), emoji reactions (`post_reactions`), bookmarks (`isSaved`), and share actions work out-of-the-box.
- **User Identity & Cards**: `Avatar.tsx`, `BrandLogo.tsx`, `PullToRefresh.tsx`, and user modal overlays integrate directly.
- **Administrative Moderation**: `AdminDashboard.tsx`, audit log trails, user restriction flags, and report queues in `server.ts` provide immediate hooks for community and event reporting.

### 1.3 Existing Database Tables Supporting Phase 2
- `profiles`: User identity, department, campus, level, and verification status.
- `posts`: Can be extended with `community_id` column (nullable foreign key) to store both public campus feed posts and community-specific discussions.
- `post_media`: Handles multi-image attachments for community posts and event posters.
- `post_reactions` & `comments`: Support engagement on community discussions.
- `notifications`: Existing notification pipeline supports community invites, join approvals, and event reminders.
- `reports`: Existing report table handles community, discussion, and event safety reports.

### 1.4 Missing Database Structures (To Be Created)
```sql
-- 1. Communities Table
CREATE TABLE IF NOT EXISTS public.communities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL, -- e.g. Academic, Departmental, Tech, Sports, Arts, Faith, General
  image_url TEXT,
  privacy TEXT NOT NULL DEFAULT 'public' CHECK (privacy IN ('public', 'private')),
  creator_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  rules TEXT,
  members_count INT NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived', 'suspended')),
  is_verified BOOLEAN NOT NULL DEFAULT false, -- Granted only by ABSU Connect super admin
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

-- 2. Community Members Table
CREATE TABLE IF NOT EXISTS public.community_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id UUID NOT NULL REFERENCES public.communities(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'moderator', 'member')),
  membership_status TEXT NOT NULL DEFAULT 'approved' CHECK (membership_status IN ('approved', 'pending', 'rejected', 'banned')),
  joined_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  UNIQUE(community_id, user_id)
);

-- 3. Community Posts Association (or community_id foreign key on posts)
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS community_id UUID REFERENCES public.communities(id) ON DELETE CASCADE;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS is_pinned BOOLEAN DEFAULT false;

-- 4. Campus Events Table
CREATE TABLE IF NOT EXISTS public.campus_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL, -- e.g. Academic, SUG, Faculty Week, Fellowship, Sports, Workshop, Social
  organizer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  venue TEXT NOT NULL,
  campus TEXT NOT NULL DEFAULT 'Uturu (Main Campus)',
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ,
  poster_url TEXT,
  status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'published', 'cancelled', 'completed')),
  visibility TEXT NOT NULL DEFAULT 'public' CHECK (visibility IN ('public', 'campus_only')),
  registration_link TEXT,
  interested_count INT NOT NULL DEFAULT 0,
  going_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

-- 5. Event Participants / RSVP Table
CREATE TABLE IF NOT EXISTS public.event_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID NOT NULL REFERENCES public.campus_events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  response TEXT NOT NULL CHECK (response IN ('interested', 'going')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  UNIQUE(event_id, user_id)
);

-- 6. Saved Events
CREATE TABLE IF NOT EXISTS public.saved_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID NOT NULL REFERENCES public.campus_events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  saved_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  UNIQUE(event_id, user_id)
);
```

### 1.5 Potential Conflicts & Mitigations
- **Feed Pollution**: If every private or irrelevant community post entered the general campus feed, students would experience noise. **Mitigation**: Filter public community posts in `for-you` with community attribution badge, while private community posts only ever render for verified `approved` members.
- **Scroll Hijacking in Modals**: As resolved in Phase 1, all new community and event creation/detail dialogs will use `createPortal(..., document.body)` so they never trap or stretch the page scroll.
- **Fake Metrics**: Zero simulated attendee counters; `interested_count` and `going_count` increment and decrement strictly through authenticated database operations with unique constraints.

---

## 2. User Experience & Visual Design

### 2.1 Theme & Design Tokens
Consistent with ABSU Connect's purple/violet identity:
- **Primary Accent**: Violet-600 (`#7c3aed`), Primary Subtle (`#7c3aed`/15).
- **Backgrounds**: `[var(--color-bg-main)]`, Card Surfaces `[var(--color-bg-card)]`, Subtle Borders `[var(--color-border)]`.
- **Zero-Pill Discipline**: Categorical tags and dates will appear as unboxed typographic metadata (`Academic · 142 Members · Uturu`), while functional filters (segmented tabs) are interactive buttons.

### 2.2 Community UX Workflow
1. **Communities Home (`CommunitiesView.tsx`)**:
   - Header with segmented navigation: **Discover Communities** (default) | **My Communities** | **Create Community**.
   - Search input with live keyword matching and clean category selector pills (`All`, `Academic`, `Departmental`, `Tech`, `Sports`, `Faith`, `Lifestyle`).
   - Community cards displaying banner/avatar, community name, verified badge (if verified by admin), description, member count, privacy badge, and a dynamic action button (`Join`, `Request to Join`, `Joined`, or `Pending`).
2. **Community Detail Page (`CommunityDetailView.tsx`)**:
   - Cover header with avatar, name, category, member count, and owner info.
   - Secondary tab bar:
     - **Discussions**: Feed of community posts, pinned announcements at top, inline composer for joined members.
     - **About**: Description, rules, privacy notice, creator, creation date.
     - **Members**: Searchable member list grouped into Owner, Admins, and Members.
   - Action controls: Leave Community, Notification Mute, Share, Admin Settings modal (for owner/admin).

### 2.3 Campus Events UX Workflow
1. **Events Hub (`CampusEventsView.tsx`)**:
   - Segmented view: **Upcoming Events** | **Happening Today** | **Saved Events** | **My Events (Organizer)**.
   - Quick date filters: `All Dates`, `This Weekend`, `Next Week`.
   - Event Card: Poster thumbnail/banner, date badge, title, venue, organizer name, `Interested` & `Going` counter buttons, and bookmark toggle.
2. **Event Details Page (`EventDetailView.tsx`)**:
   - High-res event banner, date & time breakdown, venue location map-pin, full description.
   - Interactive engagement bar: `Interested` button, `Going` button, `Save` button, `Share` button.
   - Organizer profile card and external registration button (if applicable).
3. **Event Creator & Organizer Centre (`CreateEventModal.tsx` & `OrganizerCentreView.tsx`)**:
   - Multi-step event creation with poster crop/upload, date picker, venue selector, category, and optional external RSVP link.
   - Organizer dashboard displaying active events, total views, interested vs. going engagement metrics, and edit/cancel controls.

---

## 3. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        ABSU CONNECT CLIENT                             │
├────────────────────────────────────────────────────────────────────────┤
│  DesktopSidebar / BottomNav / MoreView                                │
│       │                                                                │
│       ├──► CommunitiesView ──► CommunityDetailView ──► MemberComposer  │
│       │         │                      │                               │
│       │         ├─ Discover / Search   ├─ Discussions (PostCard)       │
│       │         ├─ My Communities      ├─ About & Rules                │
│       │         └─ Create Modal        └─ Member List (Roles)          │
│       │                                                                │
│       └──► CampusEventsView ──► EventDetailView ──► OrganizerCentre   │
│                 │                      │                               │
│                 ├─ Discover / Filters  ├─ RSVP: Interested / Going     │
│                 ├─ Saved Events        ├─ Save / Share Actions         │
│                 └─ Create Event Modal  └─ Performance Analytics        │
└──────────────────────────────────┬─────────────────────────────────────┘
                                   │ HTTPS / REST / RLS
┌──────────────────────────────────▼─────────────────────────────────────┐
│                       EXPRESS PROXY & SUPABASE                         │
├────────────────────────────────────────────────────────────────────────┤
│  REST API Routes (/api/communities/* & /api/events/*)                  │
│       │                                                                │
│       ├──► communities (id, name, slug, privacy, creator_id, ...)      │
│       ├──► community_members (community_id, user_id, role, status)     │
│       ├──► posts (community_id, author_id, body, is_pinned, ...)       │
│       ├──► campus_events (id, title, venue, start_time, organizer_id)  │
│       ├──► event_participants (event_id, user_id, response)            │
│       └──► notifications (recipient_id, sender_id, type, target_id)   │
└────────────────────────────────────────────────────────────────────────┘
```

### 3.1 Security & Row Level Security (RLS) Policies
- **Private Communities**: `SELECT` on private community posts is restricted to authenticated users with an `approved` row in `community_members`.
- **Role Permissions**:
  - `owner`: full edit/delete privileges on community.
  - `admin`: manage member requests (`approved` / `rejected`), pin posts, remove content.
  - `member`: publish discussions, comment, react.
  - Non-members: read-only on public communities; zero access on private discussions.
- **Events**: Only the event `organizer_id` or ABSU Super Admin can edit or cancel an event.
- **Service Role Keys**: Kept strictly server-side in `server.ts`; client uses Supabase anon client with RLS enforcement.

---

## 4. Step-by-Step Implementation Roadmap

```
PHASE 1: Communities Foundation (Database & Discovery)
└── 1.1 Database schemas & server endpoints for communities and memberships
└── 1.2 Community discovery view, search by name/department, and category filtering
└── 1.3 Create community modal with image upload and public/private privacy selection
└── 1.4 Join / Request-to-Join workflows with immediate state updates

PHASE 2: Community Interactions & Role-Based Discussions
└── 2.1 Community Detail view with tabs (Discussions, About, Members)
└── 2.2 Community discussion composer reusing media upload pipeline
└── 2.3 Post pinning for admins and community attribution tag in main feed
└── 2.4 Member directory and membership approval queue for private communities

PHASE 3: Campus Events System (Discovery & Engagement)
└── 3.1 Database schemas & server endpoints for campus events and RSVPs
└── 3.2 Campus events hub with date filters, categories, and event poster grid
└── 3.3 Event Detail view with venue info, organizer details, and Interested/Going toggles
└── 3.4 Student event creator modal with start/end time and poster attachments

PHASE 4: Organizer Centre & Safety Moderation
└── 4.1 My Events management tab for student organizers (edit, cancel, view RSVP list) [COMPLETED]
└── 4.2 Integration with ABSU Connect Admin Dashboard (flagged communities/events queue) [COMPLETED]
└── 4.3 Notification triggers for join approvals, event changes, and cancellations [COMPLETED]

PHASE 5: 24-Hour Stories & Official Page Applications [COMPLETED]
└── 5.1 24-hour Stories System (StoriesBar, StoryViewerModal, CreateStoryModal, story-media bucket, views, reactions, and direct message replies via RPC reply_to_story) [COMPLETED]
└── 5.2 Profile Three-Dot Menu (⋮) with Create Page, Settings, and Delete Account [COMPLETED]
└── 5.3 Campus Page Applications flow (CreatePageModal, page_applications, categories: organization, community, business, creator, other) [COMPLETED]
└── 5.4 Super Admin Review Console in AdminDashboard (AdminPagesTab, RPC review_page_application) [COMPLETED]
└── 5.5 Verified Page Badge on feed posts (PostCard.tsx) [COMPLETED]

PHASE 6: Native Android Implementation & APK Generation [COMPLETED]
└── 6.1 Fixed WebRTC compilation issues in CallActivity.java (JavaAudioDeviceModule) [COMPLETED]
└── 6.2 Fixed CallInboxSubscription.java JSONException handling and MainActivity.java lambda scope [COMPLETED]
└── 6.3 Installed Android SDK 35 and Build-tools 35; assembled release-ready debug APK (./gradlew assembleDebug) [COMPLETED]
└── 6.4 Copied native APK to public/absu-connect.apk and dist/absu-connect.apk (55 MB) [COMPLETED]
└── 6.5 Packaged full native Android project source into public/ABSU-Connect-Native-Android-Source.zip [COMPLETED]
└── 6.6 Preserved all 7 native games (WHOT, Ludo, Duel/Fighter, Fireline/Shooter, 8-Ball Billiards, Car Racing, Bike Racing), voice/video calls, and FCM [COMPLETED]
```

---

## 5. Verification & Testing Strategy
- **Community Tests**: Verified public and private communities with Supabase database persistence; no mock data.
- **Event Tests**: Verified storage upload to `event-flyers` bucket, mapped to `campus_events.poster_url`, and event participants tracking.
- **Stories Tests**: Verified active stories query (`expires_at > now()`), viewer tracking, reactions, direct message reply RPC, and image/video upload to `story-media`.
- **Page Tests**: Verified page applications insert into `page_applications` with valid categories, and admin review integration.
- **Android Compilation**: Verified clean build of `app-debug.apk` using Gradle 8.9 and Android SDK 35 without errors.
- **Web Verification**: Both `compile_applet` (`npm run build`) and `lint_applet` (`tsc --noEmit`) pass cleanly with 0 errors.

